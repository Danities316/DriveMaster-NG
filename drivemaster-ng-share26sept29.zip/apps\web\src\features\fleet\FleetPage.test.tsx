import { beforeEach, it, expect } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { FleetPage } from "./FleetPage";
import { db } from "../../db/db";
const user = { id: "u", schoolId: "s", name: "Ada", phone: "08012345678", role: "OWNER" as const };
beforeEach(async () => {
  for (const table of db.tables) await table.clear();
});
it("registers a vehicle then records an offline fuel claim with validation", async () => {
  render(<FleetPage user={user} />);
  fireEvent.click(await screen.findByRole("button", { name: "Register vehicle" }));
  fireEvent.change(screen.getByLabelText("Registration number"), {
    target: { value: "ABC-123-XY" }
  });
  fireEvent.change(screen.getByLabelText("Vehicle model"), { target: { value: "Corolla" } });
  fireEvent.click(screen.getByRole("button", { name: "Save record" }));
  await waitFor(() =>
    expect(screen.getByRole("button", { name: "Record fuel claim" })).toBeEnabled()
  );
  fireEvent.click(screen.getByRole("button", { name: "Record fuel claim" }));
  fireEvent.change(screen.getByLabelText(/Odometer/), { target: { value: "1200" } });
  fireEvent.change(screen.getByLabelText(/Fuel quantity/), { target: { value: "20" } });
  fireEvent.change(screen.getByLabelText(/Total fuel cost/), { target: { value: "19000" } });
  fireEvent.change(screen.getByLabelText(/Receipt \/ claim reference/), {
    target: { value: "REF-001" }
  });
  fireEvent.change(screen.getByLabelText(/Was the tank/), { target: { value: "yes" } });
  fireEvent.click(screen.getByRole("button", { name: "Save record" }));
  expect(await screen.findByText(/20.00 L/)).toBeInTheDocument();
  expect(screen.getByText(/Full tank · REF-001/)).toBeInTheDocument();
  expect(screen.getByText("Waiting to send")).toBeInTheDocument();
  expect((await db.fuelLogs.toArray())[0]).toMatchObject({
    cost: "19000.00",
    driverName: "Ada",
    fullTank: true
  });
  expect(await db.outbox.count()).toBe(2);
});
it("keeps inputs visible after an invalid backdated odometer reading", async () => {
  const id = crypto.randomUUID();
  await db.vehicles.add({
    id,
    schoolId: "s",
    plateNumber: "ABC123XY",
    model: "Corolla",
    status: "ACTIVE",
    createdAt: "2026-01-01",
    updatedAt: "2026-01-01"
  });
  await db.mileageLogs.add({
    id: crypto.randomUUID(),
    schoolId: "s",
    vehicleId: id,
    date: "2026-01-03T10:00:00Z",
    odometer: 1200,
    driverName: "Ada",
    recordedById: "u",
    notes: null,
    createdAt: "2026-01-03"
  });
  render(<FleetPage user={user} />);
  fireEvent.change(await screen.findByLabelText("Vehicle"), { target: { value: id } });
  fireEvent.click(screen.getByRole("button", { name: "Record mileage" }));
  fireEvent.change(screen.getByLabelText(/Date and time/), {
    target: { value: "2026-01-02T10:00" }
  });
  fireEvent.change(screen.getByLabelText(/Odometer/), { target: { value: "1300" } });
  fireEvent.click(screen.getByRole("button", { name: "Save record" }));
  expect(await screen.findByRole("alert")).toHaveTextContent(/earlier or later/);
  expect(screen.getByLabelText(/Odometer/)).toHaveValue(1300);
  expect(await db.mileageLogs.count()).toBe(1);
  expect(await db.outbox.count()).toBe(0);
});
it("shows a completed consumption cycle and recalculates when a backdated partial fill arrives", async () => {
  const common = {
    schoolId: "s",
    vehicleId: "v",
    fullTank: true,
    litres: "20.00",
    cost: "20000.00",
    discrepancyAlert: false,
    createdAt: "2026-01-01"
  };
  await db.fuelLogs.bulkAdd([
    { ...common, id: "first", date: "2026-01-01T10:00:00Z", odometer: 1000 },
    { ...common, id: "last", date: "2026-01-03T10:00:00Z", odometer: 1500 }
  ]);
  render(<FleetPage user={user} />);
  expect(await screen.findByText("4.00")).toBeInTheDocument();
  await db.fuelLogs.add({
    ...common,
    id: "partial",
    fullTank: false,
    litres: "10.00",
    cost: "10000.00",
    date: "2026-01-02T10:00:00Z",
    odometer: 1200
  });
  expect(await screen.findByText("6.00")).toBeInTheDocument();
  expect(screen.getByText("30.00 L")).toBeInTheDocument();
});

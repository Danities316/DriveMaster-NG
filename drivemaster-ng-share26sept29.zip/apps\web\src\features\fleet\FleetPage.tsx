import { FuelBenchmarkPanel } from "./FuelBenchmarkPanel";
import { assessFuelConsumption, calculateFuelConsumption } from "@drivemaster/shared";
import { useRef, useState, type FormEvent } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { Car, Fuel, Gauge, Plus } from "lucide-react";
import type { AuthenticatedUser, FleetEntity } from "@drivemaster/shared";
import { db } from "../../db/db";
import { recordFleet } from "./fleetService";
import { naira } from "../dashboard/dashboardData";
import "./fleet.css";

const localTime = () => {
  const date = new Date();
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
};
export function FleetPage({ user }: { user: AuthenticatedUser }) {
  const [flaggedOnly, setFlaggedOnly] = useState(false);
  const [vehicleId, setVehicleId] = useState("");
  const [form, setForm] = useState<FleetEntity | null>(null);
  const [recordId, setRecordId] = useState(() => crypto.randomUUID());
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const saving = useRef(false);
  const data = useLiveQuery(async () => {
    const [vehicles, mileage, fuel, queue] = await Promise.all([
      db.vehicles.where("schoolId").equals(user.schoolId).toArray(),
      db.mileageLogs.where("schoolId").equals(user.schoolId).toArray(),
      db.fuelLogs.where("schoolId").equals(user.schoolId).toArray(),
      db.outbox.where("schoolId").equals(user.schoolId).toArray()
    ]);
    return {
      vehicles: vehicles.sort((a, b) => a.plateNumber.localeCompare(b.plateNumber)),
      mileage,
      fuel,
      queue
    };
  }, [user.schoolId]);
  function open(next: FleetEntity) {
    setError("");
    setMessage("");
    setRecordId(crypto.randomUUID());
    setForm(next);
  }
  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!form || saving.current) return;
    saving.current = true;
    setBusy(true);
    setError("");
    setMessage("");
    const values = new FormData(event.currentTarget);
    const value = (name: string) => String(values.get(name) ?? "");
    try {
      if (form === "fuel_log" && !["yes", "no"].includes(value("fullTank")))
        throw new Error("Choose whether the tank was filled completely.");
      const payload =
        form === "vehicle"
          ? { id: recordId, plateNumber: value("plateNumber"), model: value("model") }
          : {
              id: recordId,
              vehicleId,
              date: new Date(value("date")).toISOString(),
              odometer: Number(value("odometer")),
              driverName: value("driverName"),
              notes: value("notes"),
              ...(form === "fuel_log"
                ? {
                    litres: value("litres"),
                    cost: value("cost"),
                    receiptReference: value("receiptReference"),
                    fullTank: value("fullTank") === "yes"
                  }
                : {})
            };
      await recordFleet(user, form, payload);
      if (form === "vehicle") setVehicleId(recordId);
      setMessage("Saved on this device and queued for synchronization.");
      setForm(null);
    } catch (reason) {
      setError(
        reason instanceof Error ? reason.message : "Unable to save. Your form has been kept."
      );
    } finally {
      saving.current = false;
      setBusy(false);
    }
  }
  if (user.role === "INSTRUCTOR") return <p>You do not have access to vehicle recording.</p>;
  if (!data)
    return (
      <p className="dashboard-loading" role="status">
        Loading vehicle records…
      </p>
    );
  const queue = new Map(data.queue.map((row) => [row.mutationId, row]));
  const intervals = calculateFuelConsumption(
    data.fuel,
    user.schoolId,
    new Set(queue.keys())
  ).filter((row) => !vehicleId || row.vehicleId === vehicleId);
  const assessed = intervals.map((cycle) => ({
    ...cycle,
    assessment: assessFuelConsumption(
      cycle,
      data.vehicles.find((vehicle) => vehicle.id === cycle.vehicleId)?.fuelBenchmark
    )
  }));
  const flagged = assessed.filter((cycle) => cycle.assessment.status === "above_limit");
  const visibleCycles = flaggedOnly ? flagged : assessed;
  const selected = data.vehicles.find((row) => row.id === vehicleId);
  const history = [
    ...data.mileage.map((row) => ({ ...row, kind: "Mileage" as const })),
    ...data.fuel.map((row) => ({ ...row, kind: "Fuel claim" as const }))
  ]
    .filter((row) => !vehicleId || row.vehicleId === vehicleId)
    .sort((a, b) => Date.parse(b.date) - Date.parse(a.date));
  const status = (id: string) => {
    const pending = queue.get(id);
    return pending
      ? pending.status === "CONFLICT" || pending.status === "FAILED"
        ? "Needs review"
        : "Waiting to send"
      : "Confirmed";
  };
  return (
    <div className="dashboard-content fleet-page">
      <div className="dashboard-heading">
        <div>
          <p className="dm-eyebrow">VEHICLE RECORDS</p>
          <h1>Mileage & fuel</h1>
          <p>
            Record the mileage and fuel bought. See when a vehicle uses more fuel than expected.
          </p>
        </div>
        <button className="dm-primary" onClick={() => open("vehicle")}>
          <Plus size={17} />
          Register vehicle
        </button>
      </div>
      <div className="dm-notice">
        Saved mileage and fuel records cannot be edited or deleted. Recording a fuel claim does not
        approve payment. After your records are sent, the app checks fuel use against the limit set
        for each vehicle.
      </div>
      <section className="dm-panel fleet-controls">
        <label htmlFor="fleet-vehicle">Vehicle</label>
        <select
          id="fleet-vehicle"
          value={vehicleId}
          onChange={(event) => {
            setVehicleId(event.target.value);
            setForm(null);
            setError("");
          }}
        >
          <option value="">All vehicles</option>
          {data.vehicles.map((vehicle) => (
            <option key={vehicle.id} value={vehicle.id}>
              {vehicle.plateNumber} · {vehicle.model} · {status(vehicle.id)}
            </option>
          ))}
        </select>
        <div className="fleet-actions">
          <button
            className="dm-secondary"
            disabled={!selected || selected.status === "INACTIVE"}
            onClick={() => open("mileage_log")}
          >
            <Gauge size={17} />
            Record mileage
          </button>
          <button
            className="dm-secondary"
            disabled={!selected || selected.status === "INACTIVE"}
            onClick={() => open("fuel_log")}
          >
            <Fuel size={17} />
            Record fuel claim
          </button>
        </div>
        <p>
          {selected
            ? `${selected.model} · ${selected.plateNumber} · ${selected.status.toLowerCase()}`
            : data.vehicles.length
              ? "Select a vehicle to record mileage or a fuel claim."
              : "Register your first vehicle to start recording."}
        </p>
      </section>
      {selected && (
        <FuelBenchmarkPanel
          key={selected.id}
          user={user}
          vehicle={selected}
          pending={data.queue.find(
            (entry) =>
              entry.entity === "vehicle" && (entry.payload as { id?: string }).id === selected.id
          )}
        />
      )}
      <section className="dm-panel" aria-labelledby="consumption-title">
        <div className="panel-heading">
          <div>
            <h2 id="consumption-title">Fuel used between two full tanks</h2>
            <p>
              Start with a full tank. Record every fuel purchase until you fill the tank again. The
              first fill is the starting point; fuel bought after it is counted.
            </p>
          </div>
        </div>
        <p className="fleet-consumption-note">
          Record every fuel purchase for a useful result. The app waits if records have not been
          sent or need checking. Refill cost per km means the fuel money spent divided by the
          kilometres travelled.
        </p>
        <div className="fleet-review-summary">
          <strong>{flagged.length} cycle(s) above the saved limit</strong>
          <label>
            <input
              type="checkbox"
              checked={flaggedOnly}
              onChange={(event) => setFlaggedOnly(event.target.checked)}
            />{" "}
            Show only high fuel use
          </label>
          <p>
            Check the mileage, fuel purchases and driving conditions. A high reading is not proof of
            a false claim. New fuel limits are used only after they have been sent.
          </p>
        </div>
        {visibleCycles.length ? (
          <div className="table-scroll">
            <table className="dm-table">
              <thead>
                <tr>
                  <th>Vehicle / period</th>
                  <th>Distance</th>
                  <th>Fuel added</th>
                  <th>L/100 km</th>
                  <th>km/L</th>
                  <th>Refill cost</th>
                  <th>Refill cost/km</th>
                  <th>Fuel check</th>
                </tr>
              </thead>
              <tbody>
                {visibleCycles.map((row) => (
                  <tr key={row.endId}>
                    <td>
                      {data.vehicles.find((vehicle) => vehicle.id === row.vehicleId)?.plateNumber ??
                        "Unknown vehicle"}
                      <small className="fleet-detail">
                        {new Date(row.startDate).toLocaleString("en-NG")} –{" "}
                        {new Date(row.endDate).toLocaleString("en-NG")}
                      </small>
                    </td>
                    <td>{row.distanceKm.toLocaleString()} km</td>
                    <td>
                      {row.litres} L
                      <small className="fleet-detail">{row.fillCount} refill(s)</small>
                    </td>
                    <td>{row.litresPer100Km.toFixed(2)}</td>
                    <td>{row.kmPerLitre.toFixed(2)}</td>
                    <td>{naira(row.refillCost)}</td>
                    <td>{naira(row.refillCostPerKm.toFixed(2))}</td>
                    <td className="fleet-assessment">
                      <strong
                        className={row.assessment.status === "above_limit" ? "fleet-flag" : ""}
                      >
                        {
                          {
                            above_limit: "Review: above limit",
                            below_range: "Below expected range",
                            within_limit: "Within limit",
                            not_configured: "Fuel limit not set"
                          }[row.assessment.status]
                        }
                      </strong>
                      {row.assessment.limit != null && (
                        <small className="fleet-detail">
                          {row.litresPer100Km.toFixed(4)} L/100 km measured;{" "}
                          {row.assessment.limit.toFixed(4)} limit.
                        </small>
                      )}
                      {row.assessment.status === "above_limit" && (
                        <small className="fleet-detail">
                          {row.assessment.excessPercent!.toFixed(2)}% over limit ·{" "}
                          {row.assessment.excessLitres!.toFixed(2)} L above allowance for{" "}
                          {row.distanceKm.toLocaleString()} km.
                        </small>
                      )}
                      {row.assessment.status === "below_range" && (
                        <small className="fleet-detail">
                          Check that every fuel purchase was entered and the fuel limit is suitable.
                        </small>
                      )}
                      {row.assessment.status === "not_configured" && (
                        <small className="fleet-detail">
                          Select this vehicle to set its fuel limit.
                        </small>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="dashboard-empty">
            <h3>
              {flaggedOnly ? "No cycles above the saved limit" : "Not enough full-tank records yet"}
            </h3>
            <p>
              {flaggedOnly
                ? "Fuel use can only be checked after two full tanks and a saved fuel limit."
                : "Record two full-tank fills at different mileage readings, plus every fuel purchase between them. Keep the app open until those records have been sent."}
            </p>
          </div>
        )}
      </section>
      {message && (
        <p className="fleet-success" role="status">
          {message}
        </p>
      )}
      {form && (
        <section className="dm-panel fleet-form-panel">
          <h2>
            {form === "vehicle"
              ? "Register vehicle"
              : form === "mileage_log"
                ? "Record mileage"
                : "Record fuel claim"}
          </h2>
          <form
            onSubmit={(event) => void save(event)}
            key={`${form}-${recordId}`}
            className="fleet-form"
          >
            {form === "vehicle" ? (
              <>
                <label>
                  Registration number
                  <input
                    name="plateNumber"
                    required
                    maxLength={30}
                    placeholder="e.g. ABC-123-XY"
                    autoFocus
                  />
                </label>
                <label>
                  Vehicle model
                  <input name="model" required maxLength={100} placeholder="e.g. Toyota Corolla" />
                </label>
              </>
            ) : (
              <>
                <label>
                  Date and time
                  <input
                    name="date"
                    type="datetime-local"
                    step="1"
                    required
                    defaultValue={localTime()}
                  />
                  <small>Uses this device’s local timezone.</small>
                </label>
                <label>
                  Odometer (km)
                  <input
                    name="odometer"
                    type="number"
                    inputMode="numeric"
                    min="0"
                    max="2147483647"
                    step="1"
                    required
                    placeholder="Whole kilometres"
                  />
                </label>
                <label>
                  Driver / instructor name
                  <input name="driverName" required maxLength={120} defaultValue={user.name} />
                </label>
                {form === "fuel_log" && (
                  <>
                    <label>
                      Fuel quantity (litres)
                      <input
                        name="litres"
                        type="number"
                        inputMode="decimal"
                        min="0.01"
                        max="999999.99"
                        step="0.01"
                        required
                      />
                    </label>
                    <label>
                      Total fuel cost (₦)
                      <input
                        name="cost"
                        type="number"
                        inputMode="decimal"
                        min="0.01"
                        max="9999999999.99"
                        step="0.01"
                        required
                      />
                    </label>
                    <label>
                      Receipt / claim reference
                      <input name="receiptReference" required maxLength={100} />
                      <small>
                        Use the receipt number or a unique reference for this claim. No receipt
                        image upload yet.
                      </small>
                    </label>
                    <label>
                      Was the tank filled completely?
                      <select name="fullTank" required defaultValue="">
                        <option value="" disabled>
                          Choose an option
                        </option>
                        <option value="yes">Yes — full tank</option>
                        <option value="no">No — partial fill</option>
                      </select>
                    </label>
                  </>
                )}
                <label className="fleet-wide">
                  Notes (optional)
                  <textarea name="notes" maxLength={500} rows={3} />
                </label>
              </>
            )}
            {error && (
              <p role="alert" className="fleet-error fleet-wide">
                {error}
              </p>
            )}
            <div className="fleet-actions fleet-wide">
              <button className="dm-primary" disabled={busy} type="submit">
                {busy ? "Saving…" : "Save record"}
              </button>
              <button
                className="dm-secondary"
                type="button"
                disabled={busy}
                onClick={() => {
                  setForm(null);
                  setError("");
                }}
              >
                Cancel
              </button>
            </div>
          </form>
        </section>
      )}
      {data.vehicles.some((row) => queue.get(row.id)?.lastError) && (
        <div className="dm-notice">
          A vehicle registration needs review. Open Synchronization for details before recording
          against that vehicle.
        </div>
      )}
      <section className="dm-panel">
        <div className="panel-heading">
          <div>
            <h2>Recording history</h2>
            <p>
              {vehicleId
                ? "Mileage readings and fuel claims for the selected vehicle"
                : "Mileage readings and fuel claims across your school"}
            </p>
          </div>
          <Car size={20} />
        </div>
        {history.length ? (
          <div className="table-scroll">
            <table className="dm-table">
              <thead>
                <tr>
                  <th>Date / time</th>
                  <th>Vehicle / driver</th>
                  <th>Record</th>
                  <th>Odometer</th>
                  <th>Fuel details</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {history.map((row) => (
                  <tr key={`${row.kind}-${row.id}`}>
                    <td>
                      {new Date(row.date).toLocaleString("en-NG", {
                        dateStyle: "medium",
                        timeStyle: "short"
                      })}
                    </td>
                    <td>
                      {data.vehicles.find((vehicle) => vehicle.id === row.vehicleId)?.plateNumber ??
                        "Unknown vehicle"}
                      <small className="fleet-detail">
                        {row.driverName || "Driver not recorded (legacy)"}
                      </small>
                    </td>
                    <td>
                      {row.kind}
                      {row.notes && <small className="fleet-detail fleet-notes">{row.notes}</small>}
                    </td>
                    <td>{row.odometer.toLocaleString()} km</td>
                    <td>
                      {row.kind === "Fuel claim" ? (
                        <>
                          {row.litres} L · {naira(row.cost)}
                          <small className="fleet-detail">
                            {row.fullTank == null
                              ? "Tank level unknown"
                              : row.fullTank
                                ? "Full tank"
                                : "Partial fill"}{" "}
                            · {row.receiptReference || "No reference (legacy)"}
                          </small>
                        </>
                      ) : (
                        "—"
                      )}
                    </td>
                    <td>
                      <span
                        className={`payment-badge ${status(row.id) === "Confirmed" ? "confirmed" : "pending"}`}
                      >
                        {status(row.id)}
                      </span>
                      {queue.get(row.id)?.lastError && (
                        <small className="fleet-detail fleet-notes fleet-error">
                          {queue.get(row.id)?.lastError}
                        </small>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="dashboard-empty">
            <Gauge size={30} />
            <h3>No readings recorded yet</h3>
            <p>Select a vehicle to save its first mileage reading or fuel claim.</p>
          </div>
        )}
      </section>
    </div>
  );
}

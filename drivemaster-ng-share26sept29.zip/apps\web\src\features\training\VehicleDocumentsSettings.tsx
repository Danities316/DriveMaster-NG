import { useState } from "react";
import type { TrainingSnapshot } from "@drivemaster/shared";
import { EntryForm, Field } from "./TrainingFields";
export function VehicleDocumentsSettings({
  snapshot,
  pending,
  onSave
}: {
  snapshot: TrainingSnapshot;
  pending: (id: string) => boolean;
  onSave: (action: string, target: string, data: unknown, version?: number) => Promise<void>;
}) {
  const [vehicleId, setVehicle] = useState("");
  const record = snapshot.vehicleDocuments?.find((r) => r.data.vehicleId === vehicleId);
  const target = record?.id ?? `documents-${vehicleId}`;
  return (
    <details className="dm-panel training-panel training-setting">
      <summary>Vehicle insurance and roadworthiness dates</summary>
      <p>
        Enter dates from the vehicle documents. Change reminder timing and warning/blocking options
        under School rules.
      </p>
      <label>
        Vehicle to update
        <select value={vehicleId} onChange={(e) => setVehicle(e.target.value)}>
          <option value="">Choose vehicle</option>
          {snapshot.vehicles.map((v) => (
            <option key={v.id} value={v.id}>
              {v.plateNumber}
            </option>
          ))}
        </select>
      </label>
      {vehicleId && (
        <EntryForm
          key={`${vehicleId}-${record?.version ?? -1}`}
          title="Save vehicle document dates"
          disabled={pending(target)}
          onSave={(f) =>
            onSave(
              "VEHICLE_DOCUMENTS",
              target,
              {
                vehicleId,
                insuranceExpiryDate: String(f.get("insuranceExpiryDate") ?? ""),
                roadworthinessExpiryDate: String(f.get("roadworthinessExpiryDate") ?? ""),
                reason: String(f.get("reason") ?? "")
              },
              record?.version
            )
          }
        >
          <Field
            label="Insurance expiry date"
            name="insuranceExpiryDate"
            type="date"
            required={false}
            initial={record?.data.insuranceExpiryDate ?? ""}
          />
          <Field
            label="Roadworthiness expiry date"
            name="roadworthinessExpiryDate"
            type="date"
            required={false}
            initial={record?.data.roadworthinessExpiryDate ?? ""}
          />
          <Field label="Reason for updating vehicle documents" name="reason" />
          {pending(target) && (
            <p>Your document change is waiting to send. Current server rules still apply.</p>
          )}
        </EntryForm>
      )}
    </details>
  );
}

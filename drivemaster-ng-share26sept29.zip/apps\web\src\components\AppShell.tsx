import { useEffect, useState, type ReactNode } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import {
  LayoutDashboard,
  Users,
  Wallet,
  RefreshCw,
  LogOut,
  Search,
  Route,
  Wifi,
  Car,
  WifiOff
} from "lucide-react";
import type { AuthenticatedUser } from "@drivemaster/shared";
import { db } from "../db/db";
import { getOrCreateDeviceId } from "../lib/device";

export type Section = "dashboard" | "list" | "payments" | "sync" | "fleet" | "training";
const items = [
  { key: "dashboard", label: "Overview", icon: LayoutDashboard },
  { key: "list", label: "Students", icon: Users },
  { key: "payments", label: "Payments", icon: Wallet },
  { key: "training", label: "Training", icon: Route },
  { key: "fleet", label: "Mileage & fuel", icon: Car },
  { key: "sync", label: "Saved records", icon: RefreshCw }
] as const;
export function AppShell({
  user,
  section,
  onNavigate,
  onLogout,
  children
}: {
  user: AuthenticatedUser;
  section: Section;
  onNavigate: (section: Section) => void;
  onLogout: () => void;
  children: ReactNode;
}) {
  const [online, setOnline] = useState(navigator.onLine);
  const sync = useLiveQuery(() => db.syncState.get(getOrCreateDeviceId()), []);
  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    return () => {
      window.removeEventListener("online", update);
      window.removeEventListener("offline", update);
    };
  }, []);
  return (
    <div className="dm-app">
      <a className="skip-link" href="#main-content">
        Skip to content
      </a>
      <aside className="dm-sidebar">
        <a
          className="dm-brand"
          href="#"
          onClick={(event) => {
            event.preventDefault();
            onNavigate("dashboard");
          }}
          aria-label="DriveMaster home"
        >
          <span className="brand-symbol">
            <Route size={24} />
          </span>
          <span>
            DriveMaster<span className="brand-ng">NG</span>
            <small>YOUR SCHOOL. IN CONTROL.</small>
          </span>
        </a>
        <p className="nav-caption">WORKSPACE</p>
        <nav aria-label="Main navigation">
          {items
            .filter((item) => user.role !== "INSTRUCTOR" || item.key === "dashboard")
            .map(({ key, label, icon: Icon }) => (
              <button
                key={key}
                aria-current={section === key ? "page" : undefined}
                className={section === key ? "nav-active" : ""}
                onClick={() => onNavigate(key)}
              >
                <Icon size={19} />
                <span>{label}</span>
                {section === key && <span className="nav-dot" />}
              </button>
            ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="workspace-label">
            <span className="workspace-icon">NG</span>
            <span>
              School workspace<small>Nigeria · NGN</small>
            </span>
          </div>
          <div className="profile-line">
            <span className="profile-avatar">{user.name.slice(0, 2).toUpperCase()}</span>
            <span>
              <strong>{user.name}</strong>
              <small>
                {user.role === "OWNER"
                  ? "School owner"
                  : user.role === "RECEPTIONIST"
                    ? "Receptionist"
                    : "Instructor"}
              </small>
            </span>
          </div>
        </div>
      </aside>
      <div className="dm-workspace">
        <header className="dm-topbar">
          <div className="breadcrumb">
            Workspace <span>/</span>
            <strong>{items.find((item) => item.key === section)?.label}</strong>
          </div>
          <div className="topbar-tools">
            {user.role !== "INSTRUCTOR" && (
              <button className="header-search" onClick={() => onNavigate("list")}>
                <Search size={17} />
                <span>Find a student</span>
              </button>
            )}
            <span className={`network-pill ${online ? "" : "network-offline"}`} role="status">
              {online ? <Wifi size={14} /> : <WifiOff size={14} />}
              <span>
                {!online
                  ? "Offline · saved locally"
                  : sync?.lastError
                    ? "Some records need checking"
                    : "Online"}
              </span>
            </span>
            <button className="header-logout" type="button" onClick={onLogout}>
              <LogOut size={18} aria-hidden="true" />
              <span>Log out</span>
            </button>
          </div>
        </header>
        <main id="main-content" tabIndex={-1}>
          {children}
        </main>
      </div>
    </div>
  );
}

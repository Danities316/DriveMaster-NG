import { useEffect, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { db } from "../db/db";
import { getOrCreateDeviceId } from "../lib/device";
import { retryFailed, resolveStudentConflict } from "../sync/controller";

export function ConnectionStatus({ schoolId }: { schoolId: string }) {
  const [online, setOnline] = useState(navigator.onLine);
  const mutations = useLiveQuery(
    () => db.outbox.where("schoolId").equals(schoolId).toArray(),
    [schoolId]
  );
  const state = useLiveQuery(() => db.syncState.get(getOrCreateDeviceId()), []);
  const unidentified = useLiveQuery(() => db.outbox.filter((entry) => !entry.schoolId).count(), []);
  const [actionError, setActionError] = useState("");
  const pending = mutations?.length ?? 0;
  const needsReview =
    mutations?.filter((mutation) => ["FAILED", "CONFLICT"].includes(mutation.status)).length ?? 0;
  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    return () => {
      window.removeEventListener("online", update);
      window.removeEventListener("offline", update);
    };
  }, []);
  async function act(action: () => Promise<void>) {
    setActionError("");
    try {
      await action();
    } catch {
      setActionError("Unable to update saved changes. Please try again.");
    }
  }
  return (
    <section
      aria-label="Saved records"
      className="border-b border-slate-200 bg-slate-100 px-4 py-2 text-sm text-slate-700"
    >
      <div role="status">
        {!online
          ? "Offline — work is saved on this device"
          : mutations?.some((entry) => entry.status === "SYNCING")
            ? "Sending saved records…"
            : state?.bootstrapComplete
              ? "Network connected"
              : "Preparing offline records…"}
        {pending
          ? ` · ${pending} record${pending === 1 ? "" : "s"} waiting to be sent. Keep this app's data until all records have been sent.`
          : state?.lastSyncAt
            ? ` · Last updated ${new Date(state.lastSyncAt).toLocaleTimeString()}`
            : ""}
        {needsReview
          ? ` · ${needsReview} change${needsReview === 1 ? " needs" : "s need"} review.`
          : ""}
      </div>
      {unidentified ? (
        <p className="mt-1 text-amber-800">
          {unidentified} older saved change(s) need administrator recovery because their school
          could not be identified. Keep this app's data.
        </p>
      ) : null}
      {state?.lastError ? <p className="mt-1 text-amber-800">{state.lastError}</p> : null}
      {state?.authRequired ? (
        <p>Log out and sign in again to resume. Your saved work will remain on this device.</p>
      ) : null}
      <button
        type="button"
        className="min-h-[48px] rounded border border-slate-300 px-3"
        onClick={() => void act(() => retryFailed(schoolId))}
        disabled={!online}
      >
        Send saved records / try again
      </button>
      {actionError ? <p role="alert">{actionError}</p> : null}
      {needsReview ? (
        <details className="mt-2">
          <summary className="min-h-[48px] cursor-pointer">Review saved changes</summary>
          <ul className="space-y-3">
            {mutations
              ?.filter((entry) => ["FAILED", "CONFLICT"].includes(entry.status))
              .map((entry) => (
                <li key={entry.mutationId} className="rounded border border-amber-300 bg-white p-3">
                  <p className="font-medium">
                    {entry.entity === "payment"
                      ? "Payment"
                      : entry.entity === "vehicle"
                        ? "Vehicle"
                        : entry.entity === "mileage_log"
                          ? "Mileage reading"
                          : entry.entity === "fuel_log"
                            ? "Fuel claim"
                            : "Student change"}
                    : {entry.status === "CONFLICT" ? "needs review" : "not yet sent"}
                  </p>
                  <p>{entry.lastError}</p>
                  {entry.serverStudent &&
                  entry.entity === "student" &&
                  entry.action === "UPDATE" ? (
                    <>
                      <p className="mt-2">
                        Latest server record: {entry.serverStudent.name},{" "}
                        {entry.serverStudent.phone}, tuition ₦{entry.serverStudent.totalTuition}
                      </p>
                      <dl className="mt-2">
                        {Object.entries(entry.payload as Record<string, unknown>)
                          .filter(([key]) => key !== "id")
                          .map(([key, value]) => (
                            <div key={key}>
                              <dt className="inline font-medium">
                                Your{" "}
                                {(
                                  {
                                    name: "name",
                                    phone: "phone",
                                    licenseNumber: "license number",
                                    enrollmentDate: "enrollment date",
                                    totalTuition: "tuition"
                                  } as Record<string, string>
                                )[key] ?? "change"}
                                :{" "}
                              </dt>
                              <dd className="inline">{String(value ?? "None")}</dd>
                            </div>
                          ))}
                      </dl>
                      <div className="mt-2 flex flex-wrap gap-2">
                        <button
                          type="button"
                          className="min-h-[48px] rounded border px-3"
                          onClick={() =>
                            void act(() => resolveStudentConflict(entry.mutationId, true, schoolId))
                          }
                        >
                          Keep my changes
                        </button>
                        <button
                          type="button"
                          className="min-h-[48px] rounded border px-3"
                          onClick={() =>
                            void act(() =>
                              resolveStudentConflict(entry.mutationId, false, schoolId)
                            )
                          }
                        >
                          Use server for this change
                        </button>
                      </div>
                    </>
                  ) : entry.status === "CONFLICT" ? (
                    <p>
                      Contact your school administrator to review this record. It will not be
                      overwritten automatically.
                    </p>
                  ) : null}
                </li>
              ))}
          </ul>
        </details>
      ) : null}
    </section>
  );
}

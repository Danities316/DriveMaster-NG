import { useRef, useState, type FormEvent } from "react";
import { multiplyTrainingMoney, subtractMoney, type TrainingOuting } from "@drivemaster/shared";
import { naira } from "../dashboard/dashboardData";

const localTime = (date = new Date()) =>
  new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
type Props = {
  outing: TrainingOuting;
  name: (id: string) => string;
  disabled: boolean;
  onSave: (payload: unknown) => Promise<void>;
};
function Input({
  label,
  name,
  type = "text",
  initial,
  min,
  max,
  step,
  required = true
}: {
  label: string;
  name: string;
  type?: string;
  initial?: string | number;
  min?: string | number;
  max?: string | number;
  step?: string;
  required?: boolean;
}) {
  return (
    <label>
      {label}
      <input
        name={name}
        type={type}
        defaultValue={initial}
        min={min}
        max={max}
        step={step}
        required={required}
        maxLength={500}
      />
    </label>
  );
}
export function StartOutingForm({ outing, name, disabled, onSave }: Props) {
  const [present, setPresent] = useState<string[]>([]);
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy || disabled) return;
    if (!present.length) {
      setError("Choose at least one student who is here before starting.");
      return;
    }
    const f = new FormData(event.currentTarget);
    const startedAt = new Date(String(f.get("startedAt")));
    if (startedAt.getTime() > Date.now() + 300000) {
      setError("The start time cannot be in the future. Check the time entered.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      await onSave({
        startedAt: startedAt.toISOString(),
        odometer: Number(f.get("odometer")),
        present
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save. Please try again.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <form className="training-form" onSubmit={(event) => void submit(event)}>
      <fieldset>
        <legend>Who is here for this training trip?</legend>
        <p>
          Tick only the students you can see. Anyone absent keeps their lesson for another date.
        </p>
        {outing.members.map((m) => (
          <label className="training-check" key={m.studentId}>
            <input
              type="checkbox"
              checked={present.includes(m.studentId)}
              onChange={(e) =>
                setPresent(
                  e.target.checked
                    ? [...present, m.studentId]
                    : present.filter((id) => id !== m.studentId)
                )
              }
            />
            {name(m.studentId)}
          </label>
        ))}
      </fieldset>
      <Input
        label="Actual start time"
        name="startedAt"
        type="datetime-local"
        initial={localTime()}
      />
      <Input
        label="Start mileage (km)"
        name="odometer"
        type="number"
        min={0}
        max={2147483647}
        step="1"
      />
      <p className="workflow-total" role="status">
        {present.length} students present × {naira(outing.fuelPerStudent)} ={" "}
        <strong>
          {naira(multiplyTrainingMoney(outing.fuelPerStudent, present.length))} fuel money to issue
        </strong>
        . Allow {present.length * 30} minutes of driving in total.
      </p>
      {error && (
        <p role="alert" className="fleet-error">
          {error}
        </p>
      )}
      <button className="dm-primary" disabled={disabled || busy || !present.length}>
        {busy ? "Saving…" : "Start training"}
      </button>
    </form>
  );
}

export function FinishOutingForm({ outing, name, disabled, onSave }: Props) {
  const [fuelBought, setFuelBought] = useState(true);
  const [step, setStep] = useState(0),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const [review, setReview] = useState<FormData>();
  const formRef = useRef<HTMLFormElement>(null);
  const heading = useRef<HTMLHeadingElement>(null);
  const members = outing.members.filter((m) => m.status === "DRIVING");
  const titles = ["Driving time and mileage", "Fuel bought", "Check and save"];
  const read = (f: FormData, key: string) => String(f.get(key) ?? "");
  function go(next: number) {
    setStep(next);
    setError("");
    requestAnimationFrame(() => heading.current?.focus());
  }
  function validate(section: number) {
    const form = formRef.current!;
    const fields = form.querySelectorAll<HTMLInputElement | HTMLSelectElement>(
      `[data-step="${section}"] input, [data-step="${section}"] select`
    );
    for (const field of fields) {
      if (field.disabled) continue;
      field.setCustomValidity("");
      if (!field.checkValidity()) {
        field.reportValidity();
        return false;
      }
    }
    const f = new FormData(form);
    const end = Date.parse(read(f, "endedAt")),
      start = Date.parse(outing.startedAt!);
    const fail = (fieldName: string, message: string) => {
      const field = form.elements.namedItem(fieldName) as HTMLInputElement;
      field.setCustomValidity(message);
      field.reportValidity();
      setError(message);
      return false;
    };
    if (section === 0) {
      if (end <= start || end > Date.now() + 300000 || end - start > 43200000)
        return fail(
          "endedAt",
          "Choose a finish time after the start, no later than now, and within 12 hours of starting."
        );
      const minutes = members.reduce((sum, m) => sum + Number(f.get(`minutes-${m.studentId}`)), 0);
      if (minutes > (end - start) / 60000)
        return fail(
          "endedAt",
          `You entered ${minutes} driving minutes. The training trip must last at least that long. Check the finish time or driving minutes.`
        );
    }
    if (section === 1 && fuelBought) {
      const fuelTime = Date.parse(read(f, "fuelDate"));
      if (fuelTime < start || fuelTime > end)
        return fail(
          "fuelDate",
          "Enter the time fuel was bought between the start and finish of this training trip."
        );
      if (Number(f.get("fuelOdometer")) > Number(f.get("odometer")))
        return fail(
          "fuelOdometer",
          "Fuel purchase mileage cannot be higher than the ending mileage."
        );
    }
    return true;
  }
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy || disabled) return;
    if (step < 2) {
      if (!validate(step)) return;
      setReview(new FormData(formRef.current!));
      go(step + 1);
      return;
    }
    const f = new FormData(formRef.current!);
    setBusy(true);
    setError("");
    try {
      await onSave({
        endedAt: new Date(read(f, "endedAt")).toISOString(),
        odometer: Number(f.get("odometer")),
        fuelSpent: fuelBought ? read(f, "fuelSpent") : "0.00",
        ...(fuelBought
          ? {
              litres: read(f, "litres"),
              receiptReference: read(f, "receiptReference"),
              fuelDate: new Date(read(f, "fuelDate")).toISOString(),
              fuelOdometer: Number(f.get("fuelOdometer")),
              fullTank: read(f, "fullTank") === "yes"
            }
          : {}),
        lessons: members.map((m) => ({
          studentId: m.studentId,
          minutes: Number(f.get(`minutes-${m.studentId}`)),
          topics: read(f, `topics-${m.studentId}`),
          note: read(f, `note-${m.studentId}`)
        }))
      });
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "Could not save. Your entries are still here. Please try again."
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <form
      ref={formRef}
      className="training-form lesson-workflow"
      noValidate
      onSubmit={(event) => void submit(event)}
      onInput={(event) => {
        if (event.target instanceof HTMLInputElement) event.target.setCustomValidity("");
      }}
    >
      <h3 ref={heading} tabIndex={-1}>
        Step {step + 1} of 3: {titles[step]}
      </h3>
      <fieldset data-step="0" hidden={step !== 0}>
        <legend>Students who attended</legend>
        <p>
          Started {new Date(outing.startedAt!).toLocaleString("en-NG")}. Starting mileage:{" "}
          {outing.startOdometer?.toLocaleString()} km.
        </p>
        <Input
          label="Actual finish time"
          name="endedAt"
          type="datetime-local"
          initial={localTime()}
        />
        <Input
          label="End mileage (km)"
          name="odometer"
          type="number"
          min={outing.startOdometer ?? 0}
          max={2147483647}
          step="1"
        />
        {members.map((m) => (
          <fieldset key={m.studentId}>
            <legend>{name(m.studentId)}</legend>
            <Input
              label={`Driving minutes — ${name(m.studentId)}`}
              name={`minutes-${m.studentId}`}
              type="number"
              min={0}
              max={180}
              step="1"
              initial={30}
            />
            <Input
              label={`What was taught? — ${name(m.studentId)}`}
              name={`topics-${m.studentId}`}
            />
            <Input
              label={`Notes (optional) — ${name(m.studentId)}`}
              name={`note-${m.studentId}`}
              required={false}
            />
          </fieldset>
        ))}
        <p>
          Enter the time each student actually drove. A full session needs at least 30 minutes. A
          shorter lesson can be recorded for the owner to review.
        </p>
      </fieldset>
      <fieldset data-step="1" hidden={step !== 1}>
        <legend>Fuel purchase details</legend>
        <p>
          Fuel money issued: <strong>{naira(outing.fuelIssued ?? "0")}</strong>. Record the purchase
          using the actual amount spent. We add the purchase to Mileage & fuel for you. The owner
          records any money returned separately.
        </p>
        <label>
          Was fuel bought during this trip?
          <select
            value={fuelBought ? "yes" : "no"}
            onChange={(e) => setFuelBought(e.target.value === "yes")}
          >
            <option value="yes">Yes</option>
            <option value="no">No — no fuel purchase</option>
          </select>
        </label>
        <fieldset disabled={!fuelBought} hidden={!fuelBought}>
          <Input
            label="Actual amount spent on fuel (₦)"
            name="fuelSpent"
            type="number"
            min="0.01"
            max="9999999999.99"
            step="0.01"
            initial={outing.fuelIssued ?? "0"}
          />
          <Input
            label="Fuel bought (litres)"
            name="litres"
            type="number"
            min="0.01"
            max="999999.99"
            step="0.01"
          />
          <Input label="Fuel receipt reference" name="receiptReference" />
          <Input label="Fuel purchase time" name="fuelDate" type="datetime-local" />
          <Input
            label="Mileage when fuel was bought (km)"
            name="fuelOdometer"
            type="number"
            min={outing.startOdometer ?? 0}
            max={2147483647}
            step="1"
          />
          <label>
            Did this purchase fill the tank completely?
            <select name="fullTank" defaultValue="" required>
              <option value="">Choose</option>
              <option value="yes">Yes, full tank</option>
              <option value="no">No, partial fill</option>
            </select>
          </label>
          <p>
            Use the actual purchase time and mileage. Do not record this receipt again on the
            vehicle page.
          </p>
        </fieldset>
        {!fuelBought && (
          <p>
            No purchase will be added. The full issued amount remains to be accounted for by the
            owner.
          </p>
        )}
      </fieldset>
      {step === 2 && review && (
        <section className="workflow-review" aria-label="Lesson summary">
          <h4>Check these details before saving</h4>
          <ul>
            {members.map((m) => (
              <li key={m.studentId}>
                <strong>{name(m.studentId)}</strong>: {read(review, `minutes-${m.studentId}`)}{" "}
                minutes · {read(review, `topics-${m.studentId}`)}
                {read(review, `note-${m.studentId}`) && ` · ${read(review, `note-${m.studentId}`)}`}
              </li>
            ))}
          </ul>
          <p>
            Finished: {new Date(read(review, "endedAt")).toLocaleString("en-NG")} · Mileage:{" "}
            {outing.startOdometer} → {read(review, "odometer")} km
          </p>
          <p>
            Fuel: {fuelBought ? read(review, "litres") : "0"} litres for{" "}
            {naira(fuelBought ? read(review, "fuelSpent") : "0")} · Receipt:{" "}
            {read(review, "receiptReference")} ·{" "}
            {fuelBought
              ? read(review, "fullTank") === "yes"
                ? "Full tank"
                : "Partial fill"
              : "No purchase"}
          </p>
          {fuelBought && (
            <p>
              Bought: {new Date(read(review, "fuelDate")).toLocaleString("en-NG")} at{" "}
              {read(review, "fuelOdometer")} km.
            </p>
          )}
          <p>
            Issued minus spent:{" "}
            {naira(
              subtractMoney(outing.fuelIssued ?? "0", fuelBought ? read(review, "fuelSpent") : "0")
            )}
            . A positive amount needs returning; a negative amount means spending exceeded the
            issued money.
          </p>
          <p>
            Students will see these lessons when the records are sent. Each student must sign in to
            confirm or report a problem.
          </p>
        </section>
      )}
      {error && (
        <p className="fleet-error" role="alert">
          {error}
        </p>
      )}
      <div className="workflow-actions">
        {step > 0 && (
          <button
            type="button"
            className="dm-secondary"
            disabled={busy}
            onClick={() => go(step - 1)}
          >
            Back
          </button>
        )}
        <button type="submit" className="dm-primary" disabled={disabled || busy}>
          {busy ? "Saving…" : step === 2 ? "Finish training" : "Continue"}
        </button>
      </div>
    </form>
  );
}

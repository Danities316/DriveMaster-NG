import { beforeEach, expect, it, vi } from "vitest";
import { fireEvent, render, screen } from "@testing-library/react";
import type { TrainingSnapshot, TrainingOuting } from "@drivemaster/shared";
import { db } from "../../db/db";
import { SchoolDay } from "./SchoolDay";
import { matchesTrainingView } from "../training/trainingViews";
const user = {
  id: "owner",
  schoolId: "school",
  name: "Ada",
  phone: "test",
  role: "OWNER" as const
};
const snapshot: TrainingSnapshot = {
  userId: user.id,
  schoolId: user.schoolId,
  viewerRole: user.role,
  packages: [],
  enrollments: [],
  salaries: [],
  settings: null,
  outings: [],
  students: [],
  instructors: [],
  vehicles: [],
  summaries: [],
  lessons: []
};
const outing: TrainingOuting = {
  instructorId: "i",
  vehicleId: "v",
  plannedStart: new Date().toISOString(),
  plannedEnd: new Date().toISOString(),
  status: "BOOKED",
  members: [
    { studentId: "a", enrollmentId: "a", minutes: 0, status: "BOOKED" },
    { studentId: "b", enrollmentId: "b", minutes: 0, status: "BOOKED" }
  ],
  fuelPerStudent: "1500.00",
  allowanceReason: "Default"
};
beforeEach(async () => {
  for (const table of db.tables) await table.clear();
});
it("counts only today's non-cancelled fuel and links confirmation problems across all dates", async () => {
  await db.trainingCache.put({
    userId: user.id,
    schoolId: user.schoolId,
    loadedAt: new Date().toISOString(),
    snapshot: {
      ...snapshot,
      outings: [
        { id: "today", version: 0, data: outing },
        { id: "cancelled", version: 0, data: { ...outing, status: "CANCELLED" } },
        {
          id: "old",
          version: 1,
          data: {
            ...outing,
            plannedStart: "2020-01-01T12:00:00Z",
            status: "COMPLETED",
            members: [
              { ...outing.members[0]!, status: "PENDING" },
              { ...outing.members[1]!, status: "DISPUTED" }
            ]
          }
        }
      ]
    }
  });
  const onTraining = vi.fn();
  render(<SchoolDay user={user} onTraining={onTraining} onFleet={vi.fn()} />);
  expect(await screen.findByRole("button", { name: /₦3,000.00 Fuel money/ })).toBeInTheDocument();
  fireEvent.click(screen.getByRole("button", { name: /1 Lessons awaiting/ }));
  expect(onTraining).toHaveBeenLastCalledWith({ tab: "outings", filter: "waiting" });
  fireEvent.click(screen.getByRole("button", { name: /1 Lessons reported/ }));
  expect(onTraining).toHaveBeenLastCalledWith({ tab: "outings", filter: "problems" });
});
it("does not show cached owner figures after the account's role changes", async () => {
  await db.trainingCache.put({
    userId: user.id,
    schoolId: user.schoolId,
    loadedAt: new Date().toISOString(),
    snapshot
  });
  const { rerender } = render(<SchoolDay user={user} onTraining={vi.fn()} onFleet={vi.fn()} />);
  expect(await screen.findByText("Your school today")).toBeInTheDocument();
  rerender(
    <SchoolDay user={{ ...user, role: "RECEPTIONIST" }} onTraining={vi.fn()} onFleet={vi.fn()} />
  );
  expect(await screen.findByText(/Training totals are not available/)).toBeInTheDocument();
  expect(screen.queryByText("Your school today")).not.toBeInTheDocument();
});
it("uses the Lagos calendar day and filters waiting and disputed members separately", () => {
  const late = { ...outing, plannedStart: "2026-09-24T23:30:00Z" };
  expect(matchesTrainingView(late, "today", new Date("2026-09-25T08:00:00Z"))).toBe(true);
  expect(
    matchesTrainingView({ ...late, status: "CANCELLED" }, "today", new Date("2026-09-25T08:00:00Z"))
  ).toBe(false);
  expect(
    matchesTrainingView(
      { ...late, members: [{ ...late.members[0]!, status: "PENDING" }] },
      "problems"
    )
  ).toBe(false);
});

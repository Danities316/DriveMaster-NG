import { beforeEach, expect, it, vi } from "vitest";
import { render, screen, fireEvent, waitFor, act } from "@testing-library/react";
import type { AuthenticatedUser, TrainingSnapshot } from "@drivemaster/shared";
import { db } from "../../db/db";
import { TrainingPage } from "./TrainingPage";
import { sendTraining } from "./trainingLocal";
const student: AuthenticatedUser = {
  id: "student-user",
  schoolId: "school",
  role: "STUDENT",
  name: "Ada",
  phone: "test"
};
const snapshot: TrainingSnapshot = {
  viewerRole: student.role,
  userId: student.id,
  schoolId: student.schoolId,
  packages: [],
  enrollments: [],
  settings: null,
  salaries: [],
  outings: [],
  students: [],
  instructors: [],
  vehicles: [],
  summaries: [],
  lessons: [
    {
      outingId: "o",
      version: 2,
      instructor: "Mr Ade",
      vehicle: "ABC123",
      date: "2026-01-02T10:00:00Z",
      minutes: 30,
      status: "PENDING",
      topics: "Braking"
    }
  ]
};
beforeEach(async () => {
  for (const table of db.tables) await table.clear();
});
it("gives students a simple private confirmation form", async () => {
  await db.trainingCache.put({
    userId: student.id,
    schoolId: student.schoolId,
    snapshot,
    loadedAt: "2026-01-02"
  });
  render(<TrainingPage user={student} />);
  expect(await screen.findByText(/Mr Ade/)).toBeInTheDocument();
  expect(screen.queryByText("Monthly instructor pay")).not.toBeInTheDocument();
  expect(screen.queryByText("Training settings")).not.toBeInTheDocument();
  fireEvent.click(screen.getByLabelText("Report a problem"));
  fireEvent.change(screen.getByLabelText("What went wrong?"), {
    target: { value: "The lesson did not take place" }
  });
  fireEvent.click(screen.getByRole("button", { name: "Send my response" }));
  await waitFor(async () => expect(await db.trainingQueue.count()).toBe(1));
  expect((await db.trainingQueue.toArray())[0]).toMatchObject({
    action: "RESPOND",
    expectedVersion: 2,
    data: { attended: false, reason: "The lesson did not take place" }
  });
});
it("lets an owner change the default fuel amount and explains existing bookings", async () => {
  const owner: AuthenticatedUser = { ...student, id: "owner", role: "OWNER" };
  await db.trainingCache.put({
    userId: owner.id,
    schoolId: owner.schoolId,
    snapshot: { ...snapshot, userId: owner.id, viewerRole: owner.role, lessons: [] },
    loadedAt: "2026-01-02"
  });
  render(<TrainingPage user={owner} />);
  fireEvent.click(await screen.findByRole("button", { name: "Training settings" }));
  fireEvent.click(screen.getByText("Fuel money per student", { selector: "summary" }));
  expect(
    screen.getByText(/Existing training trips keep their saved fuel amount/)
  ).toBeInTheDocument();
  fireEvent.change(screen.getByLabelText("Fuel per student (₦)"), { target: { value: "2000" } });
  fireEvent.change(screen.getByLabelText("Reason for this amount"), {
    target: { value: "New fuel price" }
  });
  fireEvent.click(screen.getByRole("button", { name: "Save fuel money per student" }));
  await waitFor(async () => expect(await db.trainingQueue.count()).toBe(1));
  expect((await db.trainingQueue.toArray())[0]).toMatchObject({
    action: "SETTINGS",
    data: { fuelPerStudent: "2000", reason: "New fuel price" }
  });
});

it("guides setup to instructor accounts and connects student and vehicle creation", async () => {
  const owner: AuthenticatedUser = { ...student, id: "owner", role: "OWNER" };
  await db.trainingCache.put({
    userId: owner.id,
    schoolId: owner.schoolId,
    snapshot: { ...snapshot, userId: owner.id, viewerRole: owner.role, lessons: [] },
    loadedAt: "2026-01-02"
  });
  const onAddStudent = vi.fn(),
    onVehicles = vi.fn();
  render(
    <TrainingPage
      user={owner}
      initialTab="setup"
      onAddStudent={onAddStudent}
      onVehicles={onVehicles}
    />
  );
  fireEvent.click(await screen.findByRole("button", { name: "Set up Add your instructors" }));
  expect(screen.getByLabelText("Account type")).toHaveValue("INSTRUCTOR");
  expect(screen.queryByLabelText("Student record (for student accounts)")).not.toBeInTheDocument();
  fireEvent.click(screen.getByRole("button", { name: "Set up Add a training vehicle" }));
  expect(onVehicles).toHaveBeenCalledOnce();
  fireEvent.click(screen.getByRole("button", { name: "Set up Add your first student" }));
  expect(onAddStudent).toHaveBeenCalledOnce();
  fireEvent.click(screen.getByRole("button", { name: "Set up Book the first lesson" }));
  expect(document.getElementById("book-outing")).toHaveAttribute("open");
});

it("lets the owner restart a stuck sender from the visible busy message", async () => {
  const owner: AuthenticatedUser = { ...student, id: "owner", role: "OWNER" };
  const ownerSnapshot = { ...snapshot, userId: owner.id, viewerRole: owner.role, lessons: [] };
  localStorage.clear();
  localStorage.setItem("drivemaster:lastKnownUser", JSON.stringify(owner));
  await db.trainingCache.put({
    userId: owner.id,
    schoolId: owner.schoolId,
    snapshot: ownerSnapshot,
    loadedAt: "2026-01-02"
  });
  await db.trainingQueue.put({
    id: "c",
    targetId: "pay",
    action: "SALARY",
    data: { instructorId: "i", month: "2026-09", salary: "100000.00", teachingHours: 100 },
    userId: owner.id,
    schoolId: owner.schoolId,
    role: owner.role,
    status: "PENDING",
    createdAt: Date.now(),
    attempts: 0,
    nextAttemptAt: 0
  });
  await db.syncLease.put({ key: "training", owner: "closed-tab", expiresAt: Date.now() + 120000 });
  vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, json: async () => ownerSnapshot }));
  try {
    render(<TrainingPage user={owner} />);
    await act(async () => {
      await sendTraining(owner);
    });
    fireEvent.click(await screen.findByRole("button", { name: "Restart sending" }));
    await waitFor(async () => expect(await db.trainingQueue.count()).toBe(0));
    expect(
      await screen.findByText(/All saved changes for this account have been sent/)
    ).toBeInTheDocument();
  } finally {
    vi.unstubAllGlobals();
    localStorage.clear();
  }
});

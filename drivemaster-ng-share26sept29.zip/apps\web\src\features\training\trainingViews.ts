import type { TrainingOuting } from "@drivemaster/shared";

export type TrainingView = "all" | "today" | "active" | "waiting" | "problems";
export const lagosDay = (date: string | Date) =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "Africa/Lagos",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(new Date(date));
export function matchesTrainingView(outing: TrainingOuting, view: TrainingView, now = new Date()) {
  if (view === "active") return outing.status === "STARTED";
  if (view === "today")
    return outing.status !== "CANCELLED" && lagosDay(outing.plannedStart) === lagosDay(now);
  if (view === "waiting") return outing.members.some((m) => m.status === "PENDING");
  if (view === "problems") return outing.members.some((m) => m.status === "DISPUTED");
  return true;
}

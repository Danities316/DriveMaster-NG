import { beforeEach, describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen } from "@testing-library/react";
import { db } from "../../db/db";
import { Dashboard } from "./Dashboard";
const user = {
  id: "u",
  schoolId: "school",
  role: "OWNER" as const,
  name: "Ada Owner",
  phone: "08012345678"
};
const props = () => ({
  user,
  onAdd: vi.fn(),
  onStudents: vi.fn(),
  onStudent: vi.fn(),
  onPayments: vi.fn(),
  onSync: vi.fn()
});
beforeEach(async () => {
  for (const table of db.tables) await table.clear();
});
describe("dashboard navigation", () => {
  it("includes this account's unsent training in the saved-record status", async () => {
    const command = {
      id: "pending-training",
      userId: user.id,
      schoolId: user.schoolId,
      role: user.role,
      action: "BOOK",
      targetId: "outing",
      data: {},
      status: "PENDING" as const,
      createdAt: Date.now(),
      attempts: 0,
      nextAttemptAt: 0
    };
    await db.trainingQueue.bulkPut([
      command,
      { ...command, id: "other-account", userId: "other", status: "FAILED" }
    ]);
    render(<Dashboard {...props()} />);
    expect(await screen.findByText("1 record waiting to be sent")).toBeInTheDocument();
    expect(screen.queryByText("All your records have been sent")).not.toBeInTheDocument();
    expect(screen.queryByText(/saved changes need review/)).not.toBeInTheDocument();
  });
  it("shows an honest empty state and connects quick actions", async () => {
    const callbacks = props();
    render(<Dashboard {...callbacks} />);
    expect(await screen.findByText("Your payment history starts here")).toBeInTheDocument();
    expect(screen.getByText(/Totals may be incomplete/)).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Add student" }));
    expect(callbacks.onAdd).toHaveBeenCalledOnce();
    fireEvent.click(screen.getByRole("button", { name: "Record payment" }));
    expect(callbacks.onStudents).toHaveBeenCalledOnce();
  });
  it("filters the payment ledger and opens the student's record", async () => {
    const timestamp = new Date().toISOString();
    await db.students.put({
      id: "s",
      schoolId: "school",
      name: "Bola Ade",
      phone: "08012345678",
      enrollmentDate: timestamp,
      totalTuition: "10000",
      amountPaid: "5000",
      balanceRemaining: "5000",
      licenseNumber: null,
      createdAt: timestamp,
      updatedAt: timestamp
    });
    await db.payments.put({
      id: "p",
      studentId: "s",
      schoolId: "school",
      amount: "5000",
      method: "BANK_TRANSFER",
      currency: "NGN",
      reference: "REF123",
      paymentDate: timestamp,
      createdAt: timestamp
    });
    const callbacks = props();
    render(<Dashboard {...callbacks} paymentsOnly />);
    fireEvent.click(await screen.findByRole("button", { name: /Open Bola Ade/ }));
    expect(callbacks.onStudent).toHaveBeenCalledWith("s");
    fireEvent.change(screen.getByRole("searchbox"), { target: { value: "unknown" } });
    expect(screen.getByText("No matching payments")).toBeInTheDocument();
    fireEvent.change(screen.getByRole("searchbox"), { target: { value: "REF123" } });
    expect(screen.getByText("Bola Ade")).toBeInTheDocument();
    fireEvent.change(screen.getByLabelText("Payment status"), { target: { value: "Pending" } });
    expect(screen.getByText("No matching payments")).toBeInTheDocument();
  });
});

import { useState } from "react";
import {
  lagosDay,
  moneyCents,
  sumMoney,
  subtractMoney,
  type TrainingSnapshot
} from "@drivemaster/shared";
import { EntryForm, Field } from "./TrainingFields";
import { naira } from "../dashboard/dashboardData";
export function CostReport({
  snapshot,
  pending,
  onSave
}: {
  snapshot: TrainingSnapshot;
  pending: (id: string) => boolean;
  onSave: (action: string, target: string, data: unknown, version?: number) => Promise<void>;
}) {
  const [selected, setSelected] = useState<string[]>([]),
    [mode, setMode] = useState("EQUAL"),
    [formKey, setFormKey] = useState(0);
  if (snapshot.expenses === undefined)
    return (
      <section className="dm-panel training-panel">
        <h2>Training costs and money left</h2>
        <p>Refresh training records to load the updated cost report.</p>
      </section>
    );
  const name = (id: string) => snapshot.students.find((s) => s.id === id)?.name ?? "Student";
  const liveExpenses = (snapshot.expenses ?? []).filter((e) => !e.data.voidReason);
  const unallocated = (basis: string) =>
    sumMoney(
      liveExpenses
        .filter((e) => e.data.basis === basis && !e.data.allocations.length)
        .map((e) => e.data.amount)
    );
  const total = (field: "fee" | "paid" | "balance" | "costSoFar") =>
    sumMoney(snapshot.summaries.map((s) => s[field] ?? "0"));
  return (
    <section className="dm-panel training-panel">
      <h2>Training costs and money left</h2>
      <p>
        All-time totals for students with training packages. Only accepted records are included.
        Payments received are shown separately from agreed fees.
      </p>
      <div className="eligibility-progress">
        <div>
          Agreed fees<strong>{naira(total("fee"))}</strong>
        </div>
        <div>
          Payments received<strong>{naira(total("paid"))}</strong>
        </div>
        <div>
          Costs assigned to students<strong>{naira(total("costSoFar"))}</strong>
        </div>
        <div>
          Payments received minus these costs
          <strong>{naira(subtractMoney(total("paid"), total("costSoFar")))}</strong>
        </div>
      </div>
      <p className="dm-notice">
        This is not final business profit or a bank balance. Each student gets a share of instructor
        pay based on teaching time. School expenses not shared with students are excluded from their
        costs: {naira(unallocated("RECORDED"))} recorded and {naira(unallocated("ESTIMATE"))}{" "}
        estimated. Avoid adding fuel or instructor pay here when it is already included in a lesson.
      </p>
      <div className="cost-report-scroll">
        <table>
          <caption>Each student’s lifetime training costs</caption>
          <thead>
            <tr>
              <th>Student</th>
              <th>Fees</th>
              <th>Paid</th>
              <th>Fuel purchases</th>
              <th>Instructor pay share</th>
              <th>Other recorded costs</th>
              <th>Other estimates</th>
              <th>Expected money left</th>
            </tr>
          </thead>
          <tbody>
            {snapshot.summaries.map((s) => (
              <tr key={s.studentId}>
                <th scope="row">{s.name}</th>
                <td>{naira(s.fee)}</td>
                <td>{naira(s.paid)}</td>
                <td>{naira(s.fuelCost ?? "0")}</td>
                <td>{naira(s.instructorCost ?? "0")}</td>
                <td>{naira(s.otherRecordedCost ?? "0")}</td>
                <td>{naira(s.otherEstimatedCost ?? "0")}</td>
                <td>
                  {s.expectedMargin === undefined
                    ? "Set instructor pay to complete estimate"
                    : naira(s.expectedMargin)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p>
        Expected money left = agreed fee minus recorded fuel, the instructor pay share, other
        recorded costs, estimated remaining lessons and other estimates. Fuel issued for unfinished
        trips is included in the remaining-lesson estimate, not treated as a confirmed purchase.
        Fuel bought is a spending record, not a measurement of fuel used by one student. Check
        vehicle consumption on Mileage &amp; fuel.
      </p>
      <details>
        <summary>Add an expense or estimate</summary>
        <EntryForm
          key={formKey}
          title="Save expense"
          onSave={async (f) => {
            if (
              f.get("basis") === "RECORDED" &&
              String(f.get("date")) > lagosDay(new Date().toISOString())
            )
              throw new Error("Choose Estimate for a future expense.");
            if (
              mode === "CUSTOM" &&
              (!selected.length ||
                moneyCents(sumMoney(selected.map((id) => String(f.get(`share-${id}`) ?? "0")))) !==
                  moneyCents(String(f.get("amount"))))
            )
              throw new Error(
                "Choose students and make their shares add up to the full expense amount."
              );
            await onSave("EXPENSE", crypto.randomUUID(), {
              category: String(f.get("category") ?? ""),
              date: String(f.get("date") ?? ""),
              amount: String(f.get("amount") ?? ""),
              basis: String(f.get("basis")),
              studentIds: selected,
              allocationMode: mode,
              ...(mode === "CUSTOM"
                ? {
                    allocations: selected.map((studentId) => ({
                      studentId,
                      amount: String(f.get(`share-${studentId}`) ?? "")
                    }))
                  }
                : {}),
              reason: String(f.get("reason") ?? "")
            });
            setSelected([]);
            setMode("EQUAL");
            setFormKey((old) => old + 1);
          }}
        >
          <Field label="Expense name (for example repairs, rent or materials)" name="category" />
          <Field
            label="Expense date"
            name="date"
            type="date"
            initial={lagosDay(new Date().toISOString())}
          />
          <Field
            label="Full expense amount (₦)"
            name="amount"
            type="number"
            min="0.01"
            max="9999999999.99"
            step="0.01"
          />
          <label>
            Is this recorded or estimated?
            <select name="basis">
              <option value="RECORDED">Recorded cost</option>
              <option value="ESTIMATE">Estimate (not an actual payment)</option>
            </select>
          </label>
          <fieldset>
            <legend>Which students should share this cost?</legend>
            <p>
              Choose one student, several students, or none to keep this as an unallocated school
              expense.
            </p>
            {snapshot.enrollments.map((e) => (
              <label className="training-check" key={e.id}>
                <input
                  type="checkbox"
                  checked={selected.includes(e.data.studentId)}
                  onChange={(event) =>
                    setSelected((old) =>
                      event.target.checked
                        ? [...old, e.data.studentId]
                        : old.filter((id) => id !== e.data.studentId)
                    )
                  }
                />
                {name(e.data.studentId)}
              </label>
            ))}
          </fieldset>
          <label>
            How should the cost be shared?
            <select value={mode} onChange={(e) => setMode(e.target.value)}>
              <option value="EQUAL">Share equally among selected students</option>
              <option value="CUSTOM">Enter each student’s amount</option>
            </select>
          </label>
          {mode === "CUSTOM" &&
            selected.map((id) => (
              <Field
                key={id}
                label={`${name(id)}: share (₦)`}
                name={`share-${id}`}
                type="number"
                min="0"
                step="0.01"
              />
            ))}
          <Field label="Expense note or reason" name="reason" />
        </EntryForm>
      </details>
      <details>
        <summary>Expense history ({snapshot.expenses?.length ?? 0})</summary>
        {[...(snapshot.expenses ?? [])]
          .sort((a, b) => b.data.date.localeCompare(a.data.date))
          .map((e) => (
            <article key={e.id} className="training-summary">
              <h3>
                {e.data.category} — {naira(e.data.amount)}
              </h3>
              <p>
                {e.data.date} · {e.data.basis === "ESTIMATE" ? "Estimate" : "Recorded cost"} ·{" "}
                {e.data.allocations.length
                  ? e.data.allocations
                      .map((a) => `${name(a.studentId)}: ${naira(a.amount)}`)
                      .join("; ")
                  : "Unallocated school expense"}
              </p>
              <p>{e.data.reason}</p>
              {e.data.voidReason ? (
                <p>Cancelled: {e.data.voidReason}</p>
              ) : (
                <details>
                  <summary>Correct this expense</summary>
                  <p>
                    Cancel the incorrect entry, then add a corrected entry. The original stays in
                    the history.
                  </p>
                  <EntryForm
                    title="Cancel incorrect expense"
                    disabled={pending(e.id)}
                    onSave={(f) =>
                      onSave(
                        "VOID_EXPENSE",
                        e.id,
                        { reason: String(f.get("reason") ?? "") },
                        e.version
                      )
                    }
                  >
                    <Field label="Reason for cancelling expense" name="reason" />
                  </EntryForm>
                </details>
              )}
            </article>
          ))}
      </details>
      <details>
        <summary>Fuel money to account for</summary>
        {snapshot.outings
          .filter((o) => o.data.fuelIssued !== undefined)
          .map((o) => {
            const data = o.data,
              difference = subtractMoney(data.fuelIssued ?? "0", data.fuelSpent ?? "0"),
              due = subtractMoney(difference, data.fuelReturned ?? "0");
            return (
              <article className="training-summary" key={o.id}>
                <h3>
                  {data.members.map((m) => name(m.studentId)).join(" and ")} —{" "}
                  {lagosDay(data.startedAt ?? data.plannedStart)}
                </h3>
                <p>
                  {snapshot.instructors.find((i) => i.id === data.instructorId)?.name ??
                    "Instructor"}{" "}
                  · Issued: {naira(data.fuelIssued ?? "0")} · Bought:{" "}
                  {data.status === "COMPLETED"
                    ? naira(data.fuelSpent ?? "0")
                    : "Trip still in progress"}{" "}
                  · Returned: {naira(data.fuelReturned ?? "0")}
                </p>
                {data.status === "COMPLETED" && (
                  <>
                    <p>
                      {moneyCents(difference) < 0n
                        ? `Spent above issued money: ${naira(subtractMoney("0", difference))}. Check how the extra purchase was funded.`
                        : `Still to return: ${naira(due)}`}
                    </p>
                    {data.fuelSpendingBasis !== "REPORTED" && (
                      <p>Older record: spending was based on the full issued allowance.</p>
                    )}
                    {moneyCents(due) > 0n && (
                      <EntryForm
                        title="Record money returned"
                        disabled={pending(o.id)}
                        onSave={(f) =>
                          onSave(
                            "RETURN_FUEL",
                            o.id,
                            {
                              amount: String(f.get("amount") ?? ""),
                              reason: String(f.get("reason") ?? "")
                            },
                            o.version
                          )
                        }
                      >
                        <Field
                          label="Amount received back (₦)"
                          name="amount"
                          type="number"
                          min="0.01"
                          max={due}
                          step="0.01"
                        />
                        <Field label="Return note or receipt reference" name="reason" />
                      </EntryForm>
                    )}
                  </>
                )}
              </article>
            );
          })}
      </details>
    </section>
  );
}

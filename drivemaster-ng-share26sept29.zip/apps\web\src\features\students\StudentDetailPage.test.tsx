import { beforeEach, describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { getOrCreateDeviceId } from "../../lib/device";
import { db } from "../../db/db";
import { StudentDetailPage } from "./StudentDetailPage";

const STUDENT = {
  id: "student-1",
  schoolId: "school-a",
  name: "Ada Okafor",
  phone: "+2348012345678",
  licenseNumber: "LIC-001",
  enrollmentDate: "2026-01-15T00:00:00.000Z",
  totalTuition: "150000.00",
  amountPaid: "50000.00",
  balanceRemaining: "100000.00",
  createdAt: "2026-01-15T00:00:00.000Z",
  updatedAt: "2026-01-15T00:00:00.000Z"
};

describe("StudentDetailPage payment actions", () => {
  beforeEach(async () => {
    for (const table of db.tables) await table.clear();
    await db.students.put(STUDENT);
  });

  it("shows the Record Payment action for owner/receptionist and hides it for instructor", async () => {
    const { rerender } = render(
      <StudentDetailPage
        studentId={STUDENT.id}
        onBack={() => {}}
        onEdit={() => {}}
        canRecordPayment={true}
      />
    );

    expect(await screen.findByRole("button", { name: /record payment/i })).toBeInTheDocument();

    rerender(
      <StudentDetailPage
        studentId={STUDENT.id}
        onBack={() => {}}
        onEdit={() => {}}
        canRecordPayment={false}
      />
    );

    await waitFor(() => {
      expect(screen.queryByRole("button", { name: /record payment/i })).not.toBeInTheDocument();
    });
  });

  it("validates required reference for non-cash payments", async () => {
    vi.stubGlobal("fetch", vi.fn());
    render(
      <StudentDetailPage
        studentId={STUDENT.id}
        onBack={() => {}}
        onEdit={() => {}}
        canRecordPayment={true}
      />
    );

    fireEvent.click(await screen.findByRole("button", { name: /record payment/i }));
    fireEvent.change(screen.getByLabelText(/amount/i), { target: { value: "25000.00" } });
    fireEvent.change(screen.getByLabelText(/payment method/i), {
      target: { value: "BANK_TRANSFER" }
    });
    fireEvent.click(screen.getByRole("button", { name: /^submit payment$/i }));

    await waitFor(() => {
      expect(screen.getByText(/reference is required/i)).toBeInTheDocument();
    });
  });

  it("shows an offline payment as queued and keeps it in local history", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new Error("offline")));
    render(
      <StudentDetailPage
        studentId={STUDENT.id}
        onBack={() => {}}
        onEdit={() => {}}
        canRecordPayment={true}
      />
    );

    fireEvent.click(await screen.findByRole("button", { name: /record payment/i }));
    fireEvent.change(screen.getByLabelText(/amount/i), { target: { value: "25000.00" } });
    fireEvent.click(screen.getByRole("button", { name: /^submit payment$/i }));

    expect(await screen.findByRole("status")).toHaveTextContent(
      "Payment saved on this device. Waiting to send."
    );
    await waitFor(() => {
      expect(screen.getByText("Waiting to send")).toBeInTheDocument();
      expect(screen.getByText("₦25000.00")).toBeInTheDocument();
      expect(screen.getAllByText("₦75000.00")).toHaveLength(2);
    });
  });
});

const PAYMENT_HISTORY = {
  totalPaid: "75000.00",
  outstandingBalance: "75000.00",
  payments: [
    {
      id: "payment-new",
      schoolId: "school-a",
      studentId: STUDENT.id,
      amount: "25000.00",
      paymentDate: "2026-03-15T00:00:00.000Z",
      method: "BANK_TRANSFER" as const,
      currency: "NGN" as const,
      reference: "TRX-NEW",
      createdAt: "2026-03-15T00:00:00.000Z"
    },
    {
      id: "payment-old",
      schoolId: "school-a",
      studentId: STUDENT.id,
      amount: "50000.00",
      paymentDate: "2026-02-15T00:00:00.000Z",
      method: "CASH" as const,
      currency: "NGN" as const,
      reference: null,
      createdAt: "2026-02-15T00:00:00.000Z"
    }
  ]
};

describe("StudentDetailPage financial summary and payment history", () => {
  beforeEach(async () => {
    for (const table of db.tables) await table.clear();
    await db.students.put(STUDENT);
    await db.payments.bulkPut(PAYMENT_HISTORY.payments);
    await db.students.update(STUDENT.id, { amountPaid: "75000.00", balanceRemaining: "75000.00" });
    await db.syncState.put({
      deviceId: getOrCreateDeviceId(),
      lastPulledCursor: "1",
      lastSyncAt: null,
      bootstrapComplete: true
    });
  });

  it("renders the backend financial totals and newest payments with details", async () => {
    render(<StudentDetailPage studentId={STUDENT.id} onBack={() => {}} onEdit={() => {}} />);

    expect((await screen.findAllByText("₦75000.00")).length).toBe(2);
    expect(screen.getByText("Total tuition / fees")).toBeInTheDocument();
    expect(screen.getByText("Total paid")).toBeInTheDocument();
    expect(screen.getByText("Outstanding balance")).toBeInTheDocument();
    expect(await screen.findByText("Bank transfer")).toBeInTheDocument();
    expect(screen.getByText("Reference: TRX-NEW")).toBeInTheDocument();

    const payments = screen.getAllByRole("listitem");
    expect(payments[0]).toHaveTextContent("TRX-NEW");
    expect(payments[1]).toHaveTextContent("Cash");
  });

  it("shows the empty payment state", async () => {
    await db.payments.clear();
    await db.students.update(STUDENT.id, {
      amountPaid: "0.00",
      balanceRemaining: STUDENT.totalTuition
    });

    render(<StudentDetailPage studentId={STUDENT.id} onBack={() => {}} onEdit={() => {}} />);

    expect(await screen.findByText("No payments recorded")).toBeInTheDocument();
  });

  it("shows a payment history error without hiding student details", async () => {
    await db.syncState.update(getOrCreateDeviceId(), { lastError: "Payments service unavailable" });

    render(<StudentDetailPage studentId={STUDENT.id} onBack={() => {}} onEdit={() => {}} />);

    expect(await screen.findByText(/Payments service unavailable/)).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Ada Okafor" })).toBeInTheDocument();
    expect(screen.getByText(/Payments service unavailable/)).toBeInTheDocument();
  });
});

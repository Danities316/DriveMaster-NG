import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { expect, it, vi } from "vitest";
import type { TrainingOuting } from "@drivemaster/shared";
import { FinishOutingForm, StartOutingForm } from "./LessonWorkflow";
const start = new Date(Date.now() - 7200000);
start.setSeconds(0, 0);
const local = (d: Date) => new Date(+d - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
const outing: TrainingOuting = {
  instructorId: "i",
  vehicleId: "v",
  plannedStart: start.toISOString(),
  plannedEnd: new Date(+start + 3600000).toISOString(),
  startedAt: start.toISOString(),
  startOdometer: 100,
  status: "STARTED",
  fuelPerStudent: "1500.00",
  fuelIssued: "3000.00",
  allowanceReason: "Default",
  members: ["a", "b"].map((studentId) => ({
    studentId,
    enrollmentId: studentId,
    status: "DRIVING",
    minutes: 0
  }))
};
const name = (id: string) => (id === "a" ? "Ada" : "Bola");
const change = (label: string, value: string) =>
  fireEvent.change(screen.getByLabelText(label), { target: { value } });
it("requires actual attendance selection and calculates the correct fuel total", async () => {
  const onSave = vi.fn().mockResolvedValue(undefined);
  render(<StartOutingForm outing={outing} name={name} disabled={false} onSave={onSave} />);
  expect(screen.getByRole("button", { name: "Start training" })).toBeDisabled();
  fireEvent.click(screen.getByLabelText("Ada"));
  expect(screen.getByRole("status")).toHaveTextContent("₦1,500.00 fuel money to issue");
  change("Start mileage (km)", "100");
  fireEvent.click(screen.getByRole("button", { name: "Start training" }));
  await waitFor(() =>
    expect(onSave).toHaveBeenCalledWith(expect.objectContaining({ present: ["a"], odometer: 100 }))
  );
});
it("preserves entries between steps and saves the reviewed lesson and fuel details once", async () => {
  const onSave = vi.fn().mockResolvedValue(undefined);
  render(<FinishOutingForm outing={outing} name={name} disabled={false} onSave={onSave} />);
  change("Actual finish time", local(new Date(+start + 3600000)));
  change("End mileage (km)", "120");
  change("What was taught? — Ada", "Braking");
  change("What was taught? — Bola", "Turning");
  fireEvent.click(screen.getByRole("button", { name: "Continue" }));
  expect(screen.getByRole("heading", { name: /Step 2/ })).toBeInTheDocument();
  change("Fuel bought (litres)", "3");
  change("Fuel receipt reference", "TEST-1");
  change("Fuel purchase time", local(new Date(+start + 600000)));
  change("Mileage when fuel was bought (km)", "105");
  change("Did this purchase fill the tank completely?", "no");
  fireEvent.click(screen.getByRole("button", { name: "Back" }));
  expect(screen.getByLabelText("What was taught? — Ada")).toHaveValue("Braking");
  fireEvent.click(screen.getByRole("button", { name: "Continue" }));
  expect(screen.getByLabelText("Fuel receipt reference")).toHaveValue("TEST-1");
  fireEvent.click(screen.getByRole("button", { name: "Continue" }));
  expect(onSave).not.toHaveBeenCalled();
  expect(screen.getByRole("region", { name: "Lesson summary" })).toHaveTextContent("₦3,000.00");
  fireEvent.click(screen.getByRole("button", { name: "Finish training" }));
  await waitFor(() => expect(onSave).toHaveBeenCalledOnce());
  expect(onSave).toHaveBeenCalledWith(
    expect.objectContaining({
      odometer: 120,
      fuelOdometer: 105,
      fullTank: false,
      receiptReference: "TEST-1",
      lessons: [
        { studentId: "a", minutes: 30, topics: "Braking", note: "" },
        { studentId: "b", minutes: 30, topics: "Turning", note: "" }
      ]
    })
  );
});
it("keeps an impossible driving duration on the first step with a useful error", () => {
  const onSave = vi.fn();
  render(<FinishOutingForm outing={outing} name={name} disabled={false} onSave={onSave} />);
  change("Actual finish time", local(new Date(+start + 1800000)));
  change("End mileage (km)", "120");
  change("What was taught? — Ada", "Braking");
  change("What was taught? — Bola", "Turning");
  fireEvent.click(screen.getByRole("button", { name: "Continue" }));
  expect(screen.getByRole("alert")).toHaveTextContent("60 driving minutes");
  expect(screen.getByRole("heading", { name: /Step 1/ })).toBeInTheDocument();
  expect(onSave).not.toHaveBeenCalled();
});

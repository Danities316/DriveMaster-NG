import type { TrainingSnapshot } from "@drivemaster/shared";

export function SetupGuide({
  snapshot,
  owner,
  onStep,
  onStudent,
  onVehicle
}: {
  snapshot: TrainingSnapshot;
  owner: boolean;
  onStep: (target: string) => void;
  onStudent?: () => void;
  onVehicle?: () => void;
}) {
  const monthParts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Africa/Lagos",
    year: "numeric",
    month: "2-digit"
  }).formatToParts(new Date());
  const month = `${monthParts.find((p) => p.type === "year")?.value}-${monthParts.find((p) => p.type === "month")?.value}`;
  const steps = [
    {
      title: "Add your training packages",
      detail: "Enter the fee and number of lessons you sell.",
      done: !!snapshot.packages.length,
      action: () => onStep("setup-packages"),
      allowed: owner
    },
    {
      title: "Add your instructors",
      detail: "Create a login so each instructor can record their own lessons.",
      done: !!snapshot.instructors.length,
      action: () => onStep("setup-accounts"),
      allowed: owner
    },
    {
      title: "Add a training vehicle",
      detail: "Use the vehicle’s number plate so everyone picks the right car.",
      done: !!snapshot.vehicles.length,
      action: onVehicle,
      allowed: !!onVehicle
    },
    {
      title: "Enter monthly instructor pay",
      detail:
        "This lets us estimate each student’s training cost. Add pay and planned teaching hours for this month.",
      done:
        snapshot.instructors.length > 0 &&
        snapshot.instructors.every((i) =>
          snapshot.salaries.some((s) => s.data.instructorId === i.id && s.data.month === month)
        ),
      action: () => onStep("setup-pay"),
      allowed: owner
    },
    {
      title: "Add your first student",
      detail: "Enter their name, phone number and agreed fee.",
      done: !!snapshot.students.length,
      action: onStudent,
      allowed: !!onStudent
    },
    {
      title: "Choose the student’s package",
      detail: "Check the fee before assigning it. Existing payments are kept.",
      done: !!snapshot.enrollments.length,
      action: () => onStep("setup-enrollment"),
      allowed: true
    },
    {
      title: "Book the first lesson",
      detail: "Choose the students, instructor, vehicle and time.",
      done: snapshot.outings.some((o) => o.data.status !== "CANCELLED"),
      action: () => onStep("book-outing"),
      allowed: true
    }
  ];
  const actionable = steps.filter((s) => owner || s.title !== "Enter monthly instructor pay");
  return (
    <section className="dm-panel training-panel setup-guide" aria-labelledby="setup-guide-title">
      <h2 id="setup-guide-title">Get your school ready, one step at a time</h2>
      <p>
        {actionable.filter((s) => s.done).length} of {actionable.length} steps ready. Progress
        updates after records are sent. You can return here whenever you need.
      </p>
      {!owner && <p>The school owner sets up packages, instructor accounts and monthly pay.</p>}
      <ol>
        {actionable.map((s) => (
          <li key={s.title}>
            <div>
              <strong>
                {s.done ? "✓ " : ""}
                {s.title}
              </strong>
              <p>{s.detail}</p>
            </div>
            {s.action && s.allowed ? (
              <button className="dm-secondary" onClick={s.action}>
                {s.done ? "Review" : "Set up"}
                <span className="sr-only"> {s.title}</span>
              </button>
            ) : (
              <span>{s.done ? "Ready" : "Ask the school owner"}</span>
            )}
          </li>
        ))}
      </ol>
    </section>
  );
}

import { SchoolDay, type TrainingDestination } from "./SchoolDay";
import { useEffect, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import {
  ArrowDownLeft,
  ArrowRight,
  ArrowUpRight,
  CheckCheck,
  CircleAlert,
  Plus,
  Search,
  Users,
  Wallet,
  Clock3,
  ReceiptText
} from "lucide-react";
import type { AuthenticatedUser } from "@drivemaster/shared";
import { loadDashboard, naira } from "./dashboardData";
import { db } from "../../db/db";

interface Props {
  user: AuthenticatedUser;
  paymentsOnly?: boolean;
  onAdd: () => void;
  onStudents: () => void;
  onStudent: (id: string) => void;
  onPayments: () => void;
  onSync: () => void;
  onTraining?: (destination: TrainingDestination) => void;
  onFleet?: () => void;
}
export function Dashboard({
  user,
  paymentsOnly = false,
  onAdd,
  onStudents,
  onStudent,
  onPayments,
  onSync,
  onTraining,
  onFleet
}: Props) {
  const [minute, setMinute] = useState(() => Date.now());
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("All statuses");
  const [page, setPage] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setMinute(Date.now()), 60000);
    return () => clearInterval(timer);
  }, []);
  const result = useLiveQuery(async () => {
    try {
      const [data, training] = await Promise.all([
        loadDashboard(user.schoolId, new Date(minute)),
        db.trainingQueue.where("userId").equals(user.id).toArray()
      ]);
      const ownTraining = training.filter(
        (row) => row.schoolId === user.schoolId && row.role === user.role
      );
      return {
        data: {
          ...data,
          pending: data.pending + ownTraining.length,
          review: data.review + ownTraining.filter((row) => row.status === "FAILED").length
        },
        error: false
      };
    } catch {
      return { data: null, error: true };
    }
  }, [user.id, user.schoolId, user.role, minute]);
  const data = result?.data;
  if (result?.error)
    return (
      <div className="dashboard-empty" role="alert">
        <CircleAlert />
        <h1>We couldn’t load your dashboard</h1>
        <p>Your saved records have not been changed.</p>
        <button className="dm-primary" onClick={() => setMinute(Date.now())}>
          Try again
        </button>
      </div>
    );
  if (!data)
    return (
      <div className="dashboard-loading" role="status">
        Loading your school overview…
      </div>
    );
  const rows = data.paymentRows.filter(
    (row) =>
      (status === "All statuses" || row.status === status) &&
      `${row.studentName} ${row.reference ?? ""}`.toLowerCase().includes(search.toLowerCase())
  );
  const lastPage = Math.max(0, Math.ceil(rows.length / 25) - 1);
  const currentPage = Math.min(page, lastPage);
  const max = data.days.reduce((value, day) => {
    const cents = BigInt(day.amount.replace(".", ""));
    return cents > value ? cents : value;
  }, 0n);
  const greeting =
    user.role === "OWNER" ? "Your school, at a glance." : "Ready for a productive day.";
  return (
    <div className="dashboard-content">
      <div className="dashboard-heading">
        <div>
          <p className="dm-eyebrow">{paymentsOnly ? "PAYMENT RECORDS" : "SCHOOL OVERVIEW"}</p>
          <h1>{paymentsOnly ? "Payments" : `Hello, ${user.name.split(" ")[0]}.`}</h1>
          <p>{paymentsOnly ? "See payments received and records waiting to be sent." : greeting}</p>
        </div>
        <div className="dashboard-actions">
          <button className="dm-secondary" onClick={onStudents}>
            <Wallet size={17} />
            Record payment
          </button>
          <button className="dm-primary" onClick={onAdd}>
            <Plus size={18} />
            Add student
          </button>
        </div>
      </div>
      {!paymentsOnly && onTraining && onFleet && (
        <SchoolDay user={user} onTraining={onTraining} onFleet={onFleet} />
      )}
      {!data.sync?.bootstrapComplete && (
        <div className="dm-notice">
          <Clock3 size={18} />
          <span>
            Showing saved records. Totals may be incomplete until the first update finishes.
          </span>
          <button onClick={onSync}>
            View saved records <ArrowRight size={14} />
          </button>
        </div>
      )}
      <p className="training-help">
        Payment totals come from records entered by your school. “Record sent” means saved to the
        school account; it does not verify a bank transfer.
      </p>
      <div className="dashboard-stats">
        <article className="stat-card">
          <div className="stat-label">
            Registered students <Users size={19} />
          </div>
          <strong>{data.students.length.toLocaleString()}</strong>
          <button onClick={onStudents}>
            View students <ArrowUpRight size={14} />
          </button>
        </article>
        <article className="stat-card stat-featured">
          <div className="stat-label">
            Received today <ArrowDownLeft size={20} />
          </div>
          <strong>{naira(data.todayPaid)}</strong>
          <span>Payment records sent · Lagos time</span>
        </article>
        <article className="stat-card">
          <div className="stat-label">
            Money students still owe <Wallet size={19} />
          </div>
          <strong>{naira(data.outstanding)}</strong>
          <span>{data.owing.length} students with a balance · saved tuition</span>
        </article>
        <article className="stat-card">
          <div className="stat-label">
            Records waiting to be sent <Clock3 size={19} />
          </div>
          <strong>
            {data.pending}
            <small> records</small>
          </strong>
          <button onClick={onSync}>
            {data.review ? `${data.review} need your attention` : "View saved records"}{" "}
            <ArrowUpRight size={14} />
          </button>
        </article>
      </div>
      {!paymentsOnly && (
        <div className="dashboard-middle">
          <section className="dm-panel collection-panel">
            <div className="panel-heading">
              <div>
                <h2>Payment collections</h2>
                <p>Payments recorded over the last 7 days</p>
              </div>
              <span className="dm-tag">Last 7 days</span>
            </div>
            <div className="chart-total">
              {naira(data.weekPaid)} <span>collected</span>
            </div>
            <div
              className="collection-chart"
              role="img"
              aria-label={`Payments recorded over seven days: ${data.days.map((day) => `${day.key}: ${naira(day.amount)}`).join(", ")}`}
            >
              {data.days.map((day, index) => (
                <div className="chart-column" key={day.key}>
                  <div className="bar-track">
                    <div
                      className={`chart-bar ${index === 6 ? "bar-today" : ""}`}
                      style={{
                        height: `${max ? Number((BigInt(day.amount.replace(".", "")) * 10000n) / max) / 100 : 0}%`
                      }}
                    />
                    <span className="bar-value">{naira(day.amount)}</span>
                  </div>
                  <span>{day.label}</span>
                </div>
              ))}
            </div>
            {max === 0n && <p className="chart-empty">No payment records sent in this period.</p>}
          </section>
          <section className="attention-panel">
            <div className="panel-heading">
              <h2>What needs your attention?</h2>
              <CircleAlert size={22} />
            </div>
            <p className="attention-intro">Keep your school’s records moving.</p>
            <button className="attention-item" onClick={onStudents}>
              <span className="attention-icon">
                <Wallet size={18} />
              </span>
              <span>
                <strong>{data.owing.length} students with outstanding fees</strong>
                <small>Based on payment records sent and saved fees</small>
              </span>
              <ArrowRight size={17} />
            </button>
            <button className="attention-item" onClick={onSync}>
              <span className="attention-icon">
                <CheckCheck size={18} />
              </span>
              <span>
                <strong>
                  {data.review
                    ? `${data.review} saved changes need review`
                    : data.pending
                      ? `${data.pending} record${data.pending === 1 ? "" : "s"} waiting to be sent`
                      : "All your records have been sent"}
                </strong>
                <small>
                  {data.pending
                    ? "Open saved records to see the details"
                    : "No unsent changes on this device"}
                </small>
              </span>
              <ArrowRight size={17} />
            </button>
            <div className="attention-note">
              <span className="tiny-dot" />
              {naira(data.pendingMoney)} in payment records waiting to be sent
            </div>
          </section>
        </div>
      )}
      <section className="dm-panel">
        <div className="panel-heading">
          <div>
            <h2>{paymentsOnly ? "Payment history" : "Recent payments"}</h2>
            <p>
              {paymentsOnly
                ? "Search by student or payment reference"
                : "A clear view of the latest money received"}
            </p>
          </div>
          {!paymentsOnly && (
            <button className="text-button" onClick={onPayments}>
              View all <ArrowRight size={15} />
            </button>
          )}
        </div>
        {paymentsOnly && (
          <div className="ledger-filters">
            <label className="dm-search">
              <Search size={18} />
              <input
                type="search"
                aria-label="Search payments"
                placeholder="Search student or reference…"
                value={search}
                onChange={(event) => {
                  setSearch(event.target.value);
                  setPage(0);
                }}
              />
            </label>
            <select
              aria-label="Payment status"
              value={status}
              onChange={(event) => {
                setStatus(event.target.value);
                setPage(0);
              }}
            >
              {["All statuses", "Confirmed", "Pending", "Needs review", "Conflict"].map((value) => (
                <option key={value} value={value}>
                  {value === "Confirmed"
                    ? "Record sent"
                    : value === "Pending"
                      ? "Waiting to send"
                      : value}
                </option>
              ))}
            </select>
          </div>
        )}
        {rows.length ? (
          <div className="table-scroll">
            <table className="dm-table">
              <thead>
                <tr>
                  <th>Student</th>
                  <th>Date</th>
                  <th>Method</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>
                    <span className="sr-only">Open student</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {(paymentsOnly
                  ? rows.slice(currentPage * 25, (currentPage + 1) * 25)
                  : rows.slice(0, 5)
                ).map((row) => (
                  <tr key={row.id}>
                    <td>
                      <button className="student-link" onClick={() => onStudent(row.studentId)}>
                        <span className="student-avatar">
                          {row.studentName.slice(0, 2).toUpperCase()}
                        </span>
                        <span>
                          {row.studentName}
                          <small>{row.reference || "No reference"}</small>
                        </span>
                      </button>
                    </td>
                    <td>
                      {new Date(row.paymentDate).toLocaleDateString("en-NG", {
                        day: "numeric",
                        month: "short",
                        year: "numeric",
                        timeZone: "Africa/Lagos"
                      })}
                    </td>
                    <td>
                      {{ CASH: "Cash", BANK_TRANSFER: "Bank transfer", POS: "POS" }[row.method]}
                    </td>
                    <td className="amount-cell">{naira(row.amount)}</td>
                    <td>
                      <span
                        className={`payment-badge ${row.status === "Confirmed" ? "confirmed" : "pending"}`}
                      >
                        <span />
                        {row.status === "Confirmed"
                          ? "Record sent"
                          : row.status === "Pending"
                            ? "Waiting to send"
                            : row.status}
                      </span>
                    </td>
                    <td>
                      <button
                        className="row-open"
                        aria-label={`Open ${row.studentName}'s record`}
                        onClick={() => onStudent(row.studentId)}
                      >
                        <ArrowUpRight size={17} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="dashboard-empty">
            <ReceiptText size={28} />
            <h3>
              {search || status !== "All statuses"
                ? "No matching payments"
                : "Your payment history starts here"}
            </h3>
            <p>
              {search || status !== "All statuses"
                ? "Try another name, reference, or status."
                : "Choose a student to record their first payment."}
            </p>
            {!search && status === "All statuses" && (
              <button className="dm-secondary" onClick={onStudents}>
                Find a student <ArrowRight size={16} />
              </button>
            )}
          </div>
        )}
        {paymentsOnly && rows.length > 25 && (
          <div className="ledger-pagination">
            <span>
              Page {currentPage + 1} of {lastPage + 1} · {rows.length} payments
            </span>
            <div>
              <button
                className="dm-secondary"
                disabled={currentPage === 0}
                onClick={() => setPage(currentPage - 1)}
              >
                Previous
              </button>
              <button
                className="dm-secondary"
                disabled={currentPage === lastPage}
                onClick={() => setPage(currentPage + 1)}
              >
                Next
              </button>
            </div>
          </div>
        )}
      </section>
      {!paymentsOnly && (
        <section className="dm-panel">
          <div className="panel-heading">
            <div>
              <h2>Outstanding balances</h2>
              <p>Largest saved balances, before unconfirmed payments</p>
            </div>
            <button className="text-button" onClick={onStudents}>
              All students <ArrowRight size={15} />
            </button>
          </div>
          <div className="balance-grid">
            {data.owing.slice(0, 4).map((student) => (
              <button
                key={student.id}
                className="balance-card"
                onClick={() => onStudent(student.id)}
              >
                <span className="student-avatar">{student.name.slice(0, 2).toUpperCase()}</span>
                <span>
                  <strong>{student.name}</strong>
                  <small>{naira(student.due)} outstanding</small>
                </span>
                <ArrowUpRight size={16} />
              </button>
            ))}
            {!data.owing.length && (
              <p className="clear-balances">
                {data.students.length
                  ? "No outstanding balances in your saved records."
                  : "Add your first student to get started."}
              </p>
            )}
          </div>
        </section>
      )}
      <footer className="dashboard-footer">
        <span>DriveMaster NG · Built for the way your school works.</span>
        <span>
          {data.sync?.lastSyncAt
            ? `Last updated ${new Date(data.sync.lastSyncAt).toLocaleString("en-NG", { dateStyle: "medium", timeStyle: "short" })}`
            : "Waiting for first update"}
        </span>
      </footer>
    </div>
  );
}

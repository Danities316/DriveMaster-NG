import { useLiveQuery } from "dexie-react-hooks";
import { sumMoney, multiplyTrainingMoney, type AuthenticatedUser } from "@drivemaster/shared";
import { db } from "../../db/db";
import { DocumentReminders } from "../training/DocumentReminders";
import { naira } from "./dashboardData";
import { matchesTrainingView, type TrainingView } from "../training/trainingViews";

export type TrainingDestination = {
  tab?: "outings" | "setup" | "students" | "costs";
  filter?: TrainingView;
};
export function SchoolDay({
  user,
  onTraining,
  onFleet
}: {
  user: AuthenticatedUser;
  onTraining: (destination: TrainingDestination) => void;
  onFleet: () => void;
}) {
  const cache = useLiveQuery(() => db.trainingCache.get(user.id), [user.id]);
  const snapshot =
    cache?.schoolId === user.schoolId &&
    cache.snapshot.viewerRole === user.role &&
    cache.snapshot.userId === user.id
      ? cache.snapshot
      : undefined;
  if (!snapshot)
    return (
      <section className="dm-panel school-day">
        <h2>Plan your school day</h2>
        <p>
          Open training to load your lessons and set up your school. Training totals are not
          available on this device yet.
        </p>
        <button className="dm-primary" onClick={() => onTraining({ tab: "setup" })}>
          Set up training
        </button>
      </section>
    );
  const today = snapshot.outings.filter((o) => matchesTrainingView(o.data, "today"));
  const waiting = snapshot.outings
    .flatMap((o) => o.data.members)
    .filter((m) => m.status === "PENDING").length;
  const problems = snapshot.outings
    .flatMap((o) => o.data.members)
    .filter((m) => m.status === "DISPUTED").length;
  const plannedFuel = sumMoney(
    today.map(
      (o) =>
        o.data.fuelIssued ??
        multiplyTrainingMoney(
          o.data.fuelPerStudent,
          o.data.members.filter((m) => m.status === "BOOKED").length
        )
    )
  );
  return (
    <section className="dm-panel school-day" aria-labelledby="school-day-title">
      <div className="panel-heading">
        <div>
          <h2 id="school-day-title">Your school today</h2>
          <p>
            Based on records loaded{" "}
            {new Date(cache!.loadedAt).toLocaleString("en-NG", {
              timeZone: "Africa/Lagos",
              dateStyle: "medium",
              timeStyle: "short"
            })}
            . Unsent changes may not appear yet.
          </p>
        </div>
        <button
          className="dm-primary"
          onClick={() => onTraining({ tab: "outings", filter: "today" })}
        >
          Open today’s lessons
        </button>
      </div>
      <div className="school-day-grid">
        <button onClick={() => onTraining({ tab: "outings", filter: "today" })}>
          <strong>{today.length}</strong>
          <span>Training outings today</span>
          <small>See students, instructors and vehicles</small>
        </button>
        <button onClick={() => onTraining({ tab: "outings", filter: "today" })}>
          <strong>{naira(plannedFuel)}</strong>
          <span>Fuel money for today’s outings</span>
          <small>Planned for bookings; issued for started outings</small>
        </button>
        <button onClick={() => onTraining({ tab: "outings", filter: "waiting" })}>
          <strong>{waiting}</strong>
          <span>Lessons awaiting student confirmation</span>
          <small>Across all dates · see who has not replied</small>
        </button>
        <button onClick={() => onTraining({ tab: "outings", filter: "problems" })}>
          <strong>{problems}</strong>
          <span>Lessons reported with a problem</span>
          <small>Across all dates · review student responses</small>
        </button>
      </div>
      <DocumentReminders
        snapshot={snapshot}
        loadedAt={cache?.loadedAt}
        onSettings={user.role === "OWNER" ? () => onTraining({ tab: "setup" }) : undefined}
      />
      <div className="fleet-actions school-day-actions">
        <button
          className="dm-secondary"
          onClick={() => onTraining({ tab: user.role === "OWNER" ? "costs" : "students" })}
        >
          {user.role === "OWNER" ? "See each student’s training cost" : "See student progress"}
        </button>
        <button className="dm-secondary" onClick={onFleet}>
          Check vehicle fuel records
        </button>
        <button className="dm-secondary" onClick={() => onTraining({ tab: "setup" })}>
          School setup
        </button>
      </div>
      {!snapshot.enrollments.length && (
        <p>
          New here? Open School setup to add packages, instructors and your first student’s training
          plan.
        </p>
      )}
    </section>
  );
}
